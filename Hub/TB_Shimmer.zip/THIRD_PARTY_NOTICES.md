# Third-Party Notices

TB_Shimmer is built with JUCE 8.0.12. Building and distributing the plugin must
comply with the applicable [JUCE 8 licence](https://juce.com/legal/juce-8-licence/).

No third-party DSP source code, pretrained models, fonts, presets, or runtime
network components are included. The granular processing code in this project is
an original implementation informed by publicly documented signal-processing
techniques. The fixed-memory eight-line orthogonal diffuse swarm tail, its delay
ratios, modulation, parameter derivation, feedback routing, and Factory preset
retuning are also original TB_Shimmer work.

Output Portal and Soundtoys Crystallizer are mentioned only as auditory and
workflow references. Soundtoys SpaceBlender was studied only through its public
[product page](https://www.soundtoys.com/product/spaceBlender/) and
[official user manual](https://www.soundtoys.com/wp-content/uploads/SpaceBlender-Manual.pdf)
for high-level listening vocabulary such as sparse-to-diffuse texture, evolving
spatial motion, and nonlinear ambience. No non-public material was accessed, and
no SpaceBlender algorithm, control mapping, visualizer, preset, coefficient, code,
artwork, logo, trademark asset, or product asset is included or reproduced.

Output, Portal, Soundtoys, Crystallizer, and SpaceBlender are trademarks of their
respective owners. Their mention identifies independent reference products only
and does not imply affiliation, endorsement, or compatibility.

`tb_effect_logo.png` and `shimmer_prism_glass.png` are project-owned original UI
artwork. They contain no third-party logos or text.
