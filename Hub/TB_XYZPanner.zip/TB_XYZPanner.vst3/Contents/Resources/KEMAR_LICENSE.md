# MIT KEMAR compact HRTF measurements

`kemar_hrir.zip` is an unchanged copy of the official `compact.zip` archive of KEMAR HRTF measurements by Bill Gardner and Keith Martin, MIT Media Laboratory (1994). The original 15 separately named WAV files are retained for compatibility/reference; the renderer's embedded archive now uses the original MIT entry names.

The source archive states: Copyright 1994 by the MIT Media Laboratory. The data is provided free with no restrictions on use, including research and commercial applications, provided the authors are cited when the data is used.

Source: https://sound.media.mit.edu/resources/KEMAR.html

Downloaded archive: https://sound.media.mit.edu/resources/KEMAR/compact.zip

Technical report: https://sound.media.mit.edu/resources/KEMAR/hrtfdoc.txt

Verified archive size: 231461 bytes.

Verified archive SHA-256: `0BCD69F8E8760CF8EACFF4A89594CECA7D44FB94F28ECF0BF19970003BBFB3E0`.

Suggested attribution: Bill Gardner and Keith Martin, MIT Media Laboratory, KEMAR HRTF Measurements, 1994.

The compact responses are 44.1 kHz, 16-bit stereo, 128-sample HRIR WAV files. MIT derived the compact data from the left-ear measurements, symmetrised it, and compensated for the measurement speaker's frequency response. This is measured KEMAR data, not a personalised listener HRTF.

The renderer uses 169 measured directions from elevations -40, -20, 0, +20, and +40 degrees. Each elevation covers azimuths 0 through 180 degrees; negative azimuths use the corresponding response with the ears exchanged. Zero azimuth is in front, +90 degrees is to the listener's right, and 180 degrees is behind. Height remains limited to -40 through +40 degrees, not the entire sphere.

Archive paths have the form `elev{elevation}/H{elevation}e{azimuth:000}a.wav`, for example `elev-40/H-40e006a.wav` and `elev0/H0e180a.wav`.

- Elevations -20, 0, and +20: 37 points per row, 0..180 degrees in 5-degree steps.
- Elevations -40 and +40: 29 points per row, nominal step 360/56 degrees. File names round each measured angle to an integer: 000, 006, 013, 019, 026, 032, 039, 045, 051, 058, 064, 071, 077, 084, 090, 096, 103, 109, 116, 122, 129, 135, 141, 148, 154, 161, 167, 174, 180.

To regenerate the embedded C++ resources from the pinned local archive, run `powershell -File Tools/GenerateKemarResources.ps1` from the project root. Add `-Download` to retrieve the official source again. The script verifies the pinned archive hash and all 169 required WAV formats before replacing generated files. The embedded symbols `kemar_hrir_zip` and `kemar_hrir_zipSize` are preserved.
