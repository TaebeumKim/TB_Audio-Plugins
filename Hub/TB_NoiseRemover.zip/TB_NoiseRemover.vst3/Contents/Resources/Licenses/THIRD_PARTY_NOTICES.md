# Third-Party Notices — TB_NoiseRemover

TB_NoiseRemover는 아래 제3자 소프트웨어/모델을 포함하거나 사용한다. 각 라이선스가 요구하는
저작권 고지를 아래에 그대로 포함한다. 이 파일은 배포 패키지에 함께 포함한다.
(TB_PLUGIN_RELEASE_QA_GUIDE.md 12장 "필요한 라이선스와 제3자 고지가 포함됐다")

---

## 1. FastEnhancer (신경망 음성 강화 모델)

- 용도: `fastenhancer_48k_b.onnx` — Basic 모드의 주 노이즈 제거 경로에 사용(플러그인 바이너리에 임베드).
- 파일: 릴리즈 `onnx-48khz-v1`의 `fastenhancer_b.onnx`(FFT 기반 내보내기, 449,559 B, SHA-256 `70e23bba3d41e80d30ebc5eba39d9df64f0e0315f31c772022bb17576c4d96bf`). 2026-11-15에 `onnx-48khz-convstft-v0.1.0`의 conv-STFT 내보내기(4,643,136 B)에서 교체. 같은 모델·같은 라이선스이며 출력 차이는 −138 dB.
- 출처: https://github.com/aask1357/fastenhancer
- 논문: "FastEnhancer: Speed-Optimized Streaming Neural Speech Enhancement" (ICASSP 2026), https://arxiv.org/abs/2509.21867
- 라이선스: **MIT License** — 상업적 사용·수정·재배포 허용, 저작권 고지 포함 조건.
- 확인일: 2026-07-25 (원문: 저장소 LICENSE 파일)

```
MIT License

Copyright (c) 2025 AHN Sung Hwan

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## 2. ONNX Runtime

- 용도: `onnxruntime.dll` (win-x64) — 위 모델의 실시간 추론 런타임. 플러그인/Standalone 옆에 배포.
- 출처: https://github.com/microsoft/onnxruntime
- 라이선스: MIT License, Copyright (c) Microsoft Corporation.
- 배포 DLL: `1.27.20260615.2.8f0278c`, SHA-256
  `bbb4ff18db820c24ad6d9196ecdc7a62d6099268eaadf264813a23591d4d15cc`.
- 원문 고지: `ThirdParty/ONNXRuntime/LICENSE.txt`, `ThirdPartyNotices.txt`.
  같은 버전 Python 배포에 포함된 DLL과 위 DLL의 SHA-256이 일치함을 확인하고,
  그 배포의 `ThirdPartyNotices.txt`를 보관했다. 최종 VST3 번들의
  `Contents/Resources/Licenses`에도 두 원문을 포함한다.

---

## 3. JUCE

- 용도: 플러그인 프레임워크(오디오/GUI/VST3 래퍼).
- 출처: https://juce.com
- 라이선스: 배포 형태에 따라 JUCE 상용 라이선스 또는 AGPLv3 조건이 적용된다.
- **배포 전 확인 필요:** 이 제품의 배포 방식(유료/무료, 소스 공개 여부)에 맞는 JUCE 라이선스 등급을
  확인하고 필요한 스플래시/고지 요건을 충족한다.

---

## 4. VST3 SDK (Steinberg)

- 용도: VST3 플러그인 포맷 지원(JUCE 경유).
- 라이선스: Steinberg VST3 SDK 라이선스(듀얼: 독점 라이선스 또는 GPLv3). VST3 제품 배포 시
  Steinberg 개발자 등록 및 상표 사용 조건이 적용된다.
- **배포 전 확인 필요:** VST3 배포 요건 충족 여부.

---

## 학습 데이터에 관한 참고

FastEnhancer 48kHz 모델의 **학습 데이터** 중 일부(AI-Hub 한국어 데이터셋)에는 해당 데이터셋 자체의
이용 조건(국외 반출 제한 등)이 있다. 이는 원저작자의 **학습 과정**에 적용되는 데이터셋 조건이며,
공개된 학습 결과물(가중치)의 배포 라이선스는 위 MIT License를 따른다. 데이터셋 조건이 가중치
배포까지 제약한다고 판단할 근거가 필요해지면 원저자에게 확인한다.
