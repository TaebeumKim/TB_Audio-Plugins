TB_AudioPlayer 1.0.0 — Windows x64

Included
- TB_AudioPlayer.vst3: VST3 instrument/sampler plug-in
- TB_AudioPlayer.exe: Standalone application

Install
1. Copy TB_AudioPlayer.vst3 to:
   C:\Program Files\Common Files\VST3
2. Rescan plug-ins in your DAW.
3. The standalone executable can run from any writable folder.

Operation
- BROWSE selects a WAV, AIFF, FLAC, or Ogg sample.
- PLAY starts the sample from the beginning.
- STOP fades all active playback to silence over 50 ms.
- Host parameter Trigger fires on a 0 -> 1 rising edge. Return it to 0 before the next trigger.
- Retriggering starts the new shot immediately while the previous shot fades for 50 ms.

Notes
- Selected sample files are referenced by path and are not embedded in sessions or presets.
- Maximum decoded sample memory is 256 MiB.
- MP3 is not supported in 1.0.0.

Team Impulse Impact
https://www.TeamImpulseImpact.com
