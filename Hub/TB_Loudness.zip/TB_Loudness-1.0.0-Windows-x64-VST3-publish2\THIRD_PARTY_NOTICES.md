# Third-party notices

The project uses the existing JUCE 8.0.12 SDK at `C:/JUCE`. See that SDK's
`LICENSE.md` for its licensing terms and module notices. This task does not change
or establish the user's JUCE license entitlement. A copy of the SDK license is
included in the local binary package.

The Team Impulse Impact logo is the existing canonical workspace brand asset,
copied without modification; its source/hash is recorded in `UI_DESIGN.md`.

BOOM Library UBERLOUD is an independently installed reference product, not a
dependency of TB_Loudness. No BOOM executable, code, artwork, license, or preset
is distributed in this package. Product names identify the measurement reference
only; no affiliation or endorsement is implied.

Research sources and implementation boundaries are recorded in
`PROCESSING_RESEARCH.md` and `Tests/Reference/REFERENCE_FINDINGS.md`.
