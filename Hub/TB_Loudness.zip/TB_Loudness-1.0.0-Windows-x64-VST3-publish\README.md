# TB_Loudness 0.1.0 — Windows x64 로컬 프리뷰

압축을 풀면 `TB_Loudness.vst3` 폴더와 `TB_Loudness.exe`가 있습니다.

1. DAW에서 사용하려면 **전체 `TB_Loudness.vst3` 폴더**를
   `C:\Program Files\Common Files\VST3\TB_Plugins`에 복사한 뒤 DAW에서 플러그인을 다시 검색합니다.
   내부 파일 하나만 복사하면 정상 인식되지 않습니다.
2. 독립 실행은 `TB_Loudness.exe`를 열고 사용할 오디오 장치를 선택합니다.
3. 처음에는 Amount를 조절하고 Output으로 듣는 음량을 맞춰 비교합니다.
   Factory 프리셋, 사용자 프리셋 저장, Undo/Redo를 제공합니다.

**LFE Leek**는 실제 5.1/7.1 출력에서 동작합니다. Frequency는 저역 범위,
Amount는 `.1` 채널로 보내는 양입니다. 기본 Amount는 0%이며, 원래 메인 채널과
기존 LFE는 유지됩니다. 스테레오 출력에서는 LFE 컨트롤이 비활성화됩니다.
호스트가 허용하면 스테레오 입력→5.1/7.1 출력도 사용할 수 있습니다.

이 패키지는 로컬 테스트 빌드입니다. 자동 검사 결과와 사람이 확인할 청감·DAW 항목은
동봉한 `RELEASE_QA.md`에 구분해 두었습니다. 설치, 공개 배포, 서명은 자동 수행하지 않습니다.
원본 UBERLOUD 프로그램이나 비교용 음원은 이 플러그인 ZIP에 포함하지 않습니다.
