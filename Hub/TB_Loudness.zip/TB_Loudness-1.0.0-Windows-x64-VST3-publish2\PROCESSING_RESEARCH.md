# TB_Loudness processing research

2026-10-15 — independent implementation informed by black-box observations.

## Evidence and sources

1. [BOOM product description](https://www.boomlibrary.com/sound-effects/uberloud/)
   describes custom loudness remapping, explicitly distinguishes it from a
   conventional/upward compressor, and lists band controls, clipping, noise
   suppression and optional oversampling. This is a product description, not an
   algorithm specification.
2. [BOOM manual](https://manuals.boomlibrary.com/uberloud-manual.html)
   identifies Denoise as a frequency-dependent gate, and warns its clipper is
   not a true-peak limiter. The public material does not reveal its core formula.
3. Giannoulis, Massberg, Reiss (JAES 2012),
   [Digital Dynamic Range Compressor Design—A Tutorial and Analysis](https://eecs.qmul.ac.uk/~josh/documents/2012/GiannoulisMassbergReiss-dynamicrangecompression-JAES2012.pdf).
   Reference for envelope detection and dynamics tradeoffs, not evidence that
   UBERLOUD uses a particular detector or compression curve.
4. Parker, Zavalishin, Le Bivic (DAFx 2016),
   [Reducing the Aliasing of Nonlinear Waveshaping Using Continuous-Time Convolution](https://www.dafx.de/paper-archive/2016/dafxpapers/20-DAFx-16_paper_41-PN.pdf).
   Explains why nonlinearity generates aliasing and compares antiderivative
   antialiasing. We do not copy reference code or claim this is BOOM's method.
5. [JUCE Oversampling documentation](https://docs.juce.com/master/classjuce_1_1dsp_1_1Oversampling.html)
   and the installed `C:/JUCE/modules/juce_dsp/processors/juce_Oversampling.h`.
   FIR mode provides linear phase at the cost of latency. Allocate in prepare;
   compensate and report exact integer latency.

## Candidate comparison

| Candidate | Strength | Failure risks | Decision |
|---|---|---|---|
| Static broadband soft saturation | Small, immediate crest reduction | Input-dependent sweet spot, intermodulation, insufficient body control | Keep only as finishing stage |
| Linked envelope-driven power gain plus oversampled sine saturation | Bounded density macro, predictable quiet-source behaviour, controllable transient/steady differences | May pump or raise noise; detector differs from proprietary remapping | Selected following measured transfer slope and history dependence |
| STFT magnitude remapping | Fine frequency-selective control | Window latency, transient smear, musical noise, magnitude/phase interaction | Not selected without evidence that complexity improves the target |
| Neural black-box model | Can fit measured input/output data | Training corpus, model/runtime dependency and unbounded extrapolation risk | Outside minimal local scope |

## Reference measurement boundary

The installed reference is loaded normally through a new isolated JUCE test host.
No original binary or license state is changed. Metadata and measurements live
in `Tests/Reference/`; numerical observations take precedence over hypotheses.
Tone transfer, stepped levels and harmonics cannot uniquely identify an internal
algorithm. Model similarity must not be reported as exact reverse-engineered code.

## Realtime and feature cost plan

| Work | Class | Scheduling / bound |
|---|---|---|
| Audio processing and delay alignment | Core audio | Always for active audio; no allocation/locks/files |
| Oversampling | Audible DSP | Fixed configuration, prepare-time buffers, chunks <=512 base samples |
| Band split / body curve | Audible DSP | All five split/detector paths stay warm for mode crossfades; selected band count controls the audible sum; no graph allocation on changes |
| Cleanup | Conditional audible DSP | Zero disables attenuation; detector state follows audio |
| Peak/clip meters | Display only | Gated by visible editor; atomic scalar publication |
| GUI repaint | Display only | One <=25Hz timer, only visible changing meter area |
| Presets / XML / files | Control | Non-audio thread, complete validation before apply |

Measure callback time against `1000 * blockSize / sampleRate` milliseconds;
report hardware/sample rate/block/percentiles rather than claiming a generic CPU
percentage. Host runtime and human audition remain separate from offline tests.

## License and implementation provenance

Production code is newly authored in this project, using the user's existing
JUCE SDK and canonical TB logo under existing workspace terms. JUCE's local
LICENSE.md governs the SDK; no license tier or commercial entitlement is inferred.
Papers are algorithm references only. No BOOM code, artwork or presets are bundled.

## Validation

Use shared `Guide MD/Tools/TestSignals` assets and selected shared real sources.
Measure silence, neutrality, finite extrema, macro response, bands, stereo image,
latency/bypass, variable blocks, and RMS/peak-matched source renders. Human
listening is explicitly pending until a person performs it; metrics are not its substitute.

## Measured reference and final model

See `Tests/Reference/REFERENCE_FINDINGS.md` for the reproducible 420 tone conditions,
stepped signals, native metadata and unchanged original-binary hash. UBERLOUD loaded
normally. Push-dependent quiet-source transfer slopes are approximately 1, 0.8, 0.6,
0.2 at 0, 25, 50, 100 percent; dynamics have fast gain reduction and slow recovery.
The independent static candidate `sin(1.2477275097*x)` fits Push0 on the tested
stimuli with -160.57 dBFS RMS residual. This result does not prove an internal
implementation, exact matching outside those stimuli, or character mode equivalence.

TB_Loudness uses a linked held peak envelope, bounded `envelope^(-power)` gain
(power approximately 0.8*Amount), and that measured sine coefficient in a bounded
soft knee. The 8 ms peak hold and independent recovery/character mapping are our
design, not fitted claims. Three character choices change recovery, exponent and
clip drive; BOOM's non-automatable character was unverified by the headless host.
Our Amount0 is truly neutral when Cleanup0, whereas reference Push0 was not.
Band split is a complementary one-pole residual sum; it preserves neutral summation
and intentionally uses broad overlap, not a claim of matching BOOM crossovers.
All split/detector states remain warm during mode crossfades to avoid mode-change
reinitialisation. Clip operates on the final linked-band sum before downsampling.

## Real-source calibration and static binary inspection

Both actual VST3 modules were rendered on the first 12 seconds of the shared
footstep, female voice and pad, at the source sample rate, with 256-frame blocks
and one second discarded silence preroll. Comparison settings are Full/Nice or
Smooth, Amount/Push 25 and 50, Clip/Denoise/Cleanup zero, unity trims and wet only.
Reported latency is removed without fitting a time shift. The direct Processor
and VST3 baseline outputs were sample-identical in all six cases.

The baseline model was 0.337–1.162 dB lower in whole-clip RMS than the reference;
RMS-matched correlations were 0.98237–0.99947. Some short TB peaks reached +2.323
dBFS, while all six reference renders stayed at or below 0 dBFS. Baseline evidence
is preserved under `output/AB_UBERLOUD_vs_TB_baseline` and `Tests/Calibration`.
Correlation is a signal metric, not a listening verdict or proof of equivalence.

A follow-up stereo tone probe found at -36 dBFS / 1 kHz:

| Input arrangement | Reference gain, Push25 | Reference gain, Push50 |
|---|---:|---:|
| Identical left/right | 8.961 dB | 15.993 dB |
| Left only | 10.108 dB | 18.280 dB |
| Right 6 dB lower | 9.439 dB | 16.946 dB |
| Equal opposite-polarity left/right | 13.916 dB | 25.816 dB |

This establishes phase-sensitive cross-channel coupling, consistent with a
sum-sensitive detector; it does not uniquely identify its topology. The calibrated
independent model averages **absolute** band magnitudes over mapped input channels.
It therefore models the channel averaging while deliberately keeping equal
in-phase and opposite-polarity inputs at the same gain. Silent output-only
surrounds do not enter the divisor. This differs from the measured original's
opposite-polarity gain rise.

The calibrated model also contains a linked sample-peak guard on the final wet
signal before Mix/Output. It scales channels together and follows the same
samplewise Amount fade as saturation, preserving exact Amount0 neutrality.
This small final stage runs at base rate after oversampling; it is explicitly
not an oversampled or true-peak-certified output limiter. Positive Output trim,
dry mixing, very low Amount and independent LFE summation are outside a universal
output-ceiling guarantee. Final real-source comparisons are stored in
`output/AB_UBERLOUD_vs_TB` and exact build/test evidence in `RELEASE_QA.md`.

Read-only assembly inspection found no usable DSP symbols or identifiable
signal-processing function. Near-uniform `.text` bytes, unsuitable on-disk export
disassembly and `.guard`/`.proxy` sections are consistent with a transformed or
protected file. No unpacking or original-file change was performed. The measured
sine fit was not corroborated by static disassembly; see
`Tests/Reference/Assembly/ASSEMBLY_FINDINGS.md` for the bounded evidence and limits.

## LFE extension

The LFE feature was requested separately and has no claim of originating in
UBERLOUD. A two-section Butterworth cascade forms the standard LR4 low-pass.
The cutoff derivation is bilinear-transform Butterworth with Q=1/sqrt(2);
two identical sections give -6 dB at cutoff and 24 dB/oct asymptotic attenuation.
Equal-weight mono average of mapped non-LFE channels limits coherent gain to unity.
Original LFE is only delayed; no nonlinearity is applied to it. See the brief for
bus mapping, bypass and no-virtual-LFE semantics.
