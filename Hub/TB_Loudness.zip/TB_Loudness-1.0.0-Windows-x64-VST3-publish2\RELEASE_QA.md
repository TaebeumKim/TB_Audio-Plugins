# TB_Loudness 1.0.0 — Windows release verification

Date: 2026-11-28. This is an unsigned Windows x64 release package. Automated
DSP, VST3 integration, host contract and package verification passed. Human
listening, Cubase hardware use, long-duration realtime qualification and code
signing remain open.

## Identity and build

| Field | Value |
|---|---|
| Product / version | TB_Loudness / 1.0.0 |
| Project ID / plugin code | TbLd26 / TbLd |
| Manufacturer | Team Impulse Impact / TbSd |
| Bundle identifier | com.TeamImpulseImpact.TB_Loudness |
| Category | Fx / Dynamics |
| Processor CID | ABCDEF019182FAEB5462536454624C64 |
| Controller CID | ABCDEF011234ABCD5462536454624C64 |
| State / preset format | 1 / 1 |
| Formats | Windows x64 VST3 and Standalone |
| Source-control status | Added to the existing SVN working copy in the release commit |
| Toolchain | Existing JUCE 8.0.12; Visual Studio 2022 v143, 64-bit MSBuild |
| Delivery | Windows ZIP, unsigned installer, binary SHA-256 inventory and unpack verification |

The final host metadata snapshots, final build/test results and binary hashes
are recorded below. CIDs are read from
generated module metadata and cross-checked against the actual VST3 host scan.
The first product version has no previous public-session migration requirement.

## Implemented behavior

- Input, Amount, 1/2/3 bands, Low/Mid/High weighting, two splits, three independent
  characters, Clip, Cleanup, Mix, Output and bypass: 16 stable parameters including LFE.
- Fixed 4x FIR oversampling; **138 samples** reported latency at 48 kHz (2.875 ms;
  132 / 210 / 354 at 44.1 / 96 / 192 kHz) since the 2026-10-16 DSP fixes, 61 before.
  Raw dry, input-trimmed neutral, bypass and original LFE use the same delay.
- Wet path since 2026-10-16: 1 ms lookahead lift ceiling, ADAA sine clipper, then a
  0.5 ms lookahead linked true-peak limiter (-0.09 dBTP target on its 4x estimate; a 4x
  meter reads up to +0.05 dBTP at Clip 100 Edge) before Mix and Output.
- Exactly two **LFE Leek** knobs: Frequency 20–200 Hz and Amount 0–100%.
  Post-processing bass is sent in parallel through a 24 dB/oct Linkwitz-Riley
  low-pass into the real LFE channel. At cutoff the amplitude is 0.5 (-6.02 dB).
- Native mono, stereo, 5.1, 7.1 and stereo-to-5.1/7.1. Channel identity mapping
  preserves original LFE; absent surround channels are silent. The send averages
  mapped input channels, excluding absent output-only channels from the divisor.
- Complete validated state, 12 distinct factory states in three groups, user
  presets, Undo/Redo, coherent full-preset session serialization and real meters.

## Evidence and boundaries

The installed UBERLOUD 1.2.1 was loaded normally and measured with synthetic tones
and steps. Its original SHA-256 remained unchanged. Small signals receive more
gain than large ones, with time-dependent gain recovery and nonlinear saturation;
these findings informed an independent implementation. Character/multiband
switching in the original was not verified by the headless host. No claim of an
exact clone or matching arbitrary-source sound is made. See
`Tests/Reference/REFERENCE_FINDINGS.md` and `PROCESSING_RESEARCH.md`.

The DSP harness checks silence, finite extrema at 44.1/48/96/192 kHz, variable/oversized
blocks, stereo identity, low-level density, neutral/dry/bypass alignment, band and
character influence, cleanup, clipping, automation to zero and LFE response.
The Processor harness checks actual state/preset/undo and channel-routing code.
The separate integration host loads the actual VST3 binary, tests six layouts,
compares its LFE response to the analytical LR4 formula and checks fresh-instance
state restoration plus sample-identical 7.1 audio.

At Frequency 120 Hz, the DSP measurement produced amplitude ratios of 0.987806
at 40 Hz, 0.5 at 120 Hz and 0.00020616 at 1 kHz (about -73.7 dB). Amount 50%
halves send amplitude. Stereo outputs cannot provide an LFE channel and explicitly
disable the controls; DAW support for differing input/output widths is required
for stereo-to-surround insertion.

## Defects corrected before packaging

1. An early VST3 module returned bass -7.9588 dB too low for stereo-to-5.1 and
   -10.8814 dB for stereo-to-7.1: the average included silent output channels.
   The source now divides by mapped input count. The failed actual-binary report
   is retained beside the passing rerun, rather than inferred from source changes.
2. Amount automation ending at zero previously selected dry for an entire chunk.
   The DSP now oversamples the nonlinear correction and adds delay-aligned dry per
   sample. A block-size regression covers 1, 257 and 1003 frame rendering.
3. Full-preset writes could interleave with session serialization. A control-side
   recursive lock serializes full-state transactions. Audio uses only a bounded
   atomic snapshot and never acquires that lock. Concurrent-save regression added.
4. Forced bypass now suppresses generated LFE immediately; original LFE remains
   delayed and intact. Nonfinite LFE controls are sanitized before filtering.
5. Initial 32-bit MSBuild did not generate the VST3 manifest. The final build and
   `build.ps1` use the existing 64-bit MSBuild and normal JUCE manifest helper.
6. Actual-source A/B exposed rare post-oversampling peaks up to +2.323 dBFS.
   A transient regression failed at Amount25/50/100 before the correction
   (`Tests/Calibration/Baseline_20261015/peak_regression_before.log`). The final
   linked wet guard passes each case at a maximum magnitude of 1.0, preserving
   polarity ratios, neutral/dry/bypass behavior and block-size-independent automation.
7. The initial maximum-channel detector understated stereo body relative to the
   reference. Measured stereo probes informed mean-absolute channel averaging.
   The original's antiphase-dependent gain rise is intentionally not copied.
   Active processing in stereo and stereo-to-surround now matches sample-exactly.

## UI and listening evidence

Native JUCE component snapshots at 700x472 were rendered and visually inspected:
`output/ui-qa/TB_Loudness.png` (stereo Init) and
`output/ui-qa/TB_Loudness_3band_51.png` (3-band surround with active LFE).
They establish layout/label rendering, not interactive DAW behavior.
The source drawing, reference inspections and canonical asset hash are in `UI_DESIGN.md`.

Actual-processor A/B renders use the shared footstep, female voice and pad files,
up to their first 12 seconds. Dry and processed audio are delay-aligned. Matched
files are named by the measured RMS/peak operation; RMS is not LUFS or a guarantee
of perceptual equality. Final results and source durations are in
`output/ab_calibrated`; original baseline renders remain in `output/ab`.
Both actual VST3s were additionally rendered at common Push/Amount25/50 settings.
The source samples were verified identical, reported latency removed, and outputs
compared numerically. `output/AB_UBERLOUD_vs_TB` contains RMS-matched A/B sequences
(A=UBERLOUD, 0.5-second silence, B=TB) with common sample-peak headroom. The baseline
comparison and its +2.323 dBFS brief TB overshoot are retained separately; measured
stereo coupling informed the calibrated detector and wet peak guard. See
`PROCESSING_RESEARCH.md` for deliberate departures from the original.
Human audition remains **NOT RUN**.

## Remaining checks before public release

- Human level-matched listening: transient shape, noise lift, sustained pad
  roughness, aggressive settings and original-product comparison.
- Cubase/other target DAW insertion, live automation, save/reopen, actual surround
  bus configuration, monitor calibration and physical audio outputs.
- Interactive standalone/editor verification, display scaling and keyboard behavior.
- Long-duration, GUI-open/closed, instance-count and worst-case multichannel
  realtime deadline tests. The short offline benchmark is not realtime certification.
- Public release version/pricing approval, signing, installer and distribution.

Known preview limitations: saved User preset filename identity is editor-scoped
(reopening may say Custom while preserving all values); LFE is a parallel send,
so phase-opposed bass can cancel and the existing LFE plus send can exceed unity;
no limiter or playback +10 dB calibration is applied to that LFE sum. The main wet
true-peak limiter (2026-10-16; a sample-peak guard before) acts before Mix/Output and
follows the Amount fade; the dry blend and Output are not limited, so it is not a
true-peak-certified mastering limiter.

## Final measured results

| Check | Observed result | Evidence |
|---|---|---|
| Main Debug / Release x64 | PASS; VST3 and Standalone; generated manifests; no compiler warnings/errors in final logs | `output/qa/build_main_*_calibrated.log` |
| Debug Processor / DSP | 100/100 and 53/53 PASS | `output/qa/tests_debug_calibrated.log` |
| Release Processor / DSP | 100/100 and 54/54 PASS | `output/qa/tests_release_calibrated.log` |
| Actual Release VST3 integration | 85/85 PASS; six layouts; 61-sample latency; native/fresh-state equality | `Tests/Vst3Integration/outputs/release-wrapper-calibrated.json` |
| Actual processed stereo-to-surround | 12/12 added checks; Full/2/3 bands L/R error 0 and unused channels 0 | Same integration report |
| Native Debug / Release host contract | Both exit 0; 44 Set/Get cases; 16 restored parameters; one bypass; identical snapshots | `Tests/HostContract/Debug.json`, `Release.json` |
| Final standalone startup | Running after 4 seconds; normal window close accepted; exit 0 | `output/qa/standalone-startup.json` |
| Final default/common Processor renders | 21 float WAVs per folder, exact readback; defaults at or below -1 dBFS for tested sources | `output/ab_calibrated`, `output/ab_reference_ours_calibrated` |
| Actual VST3 versus direct Processor | All six calibrated renders sample-exact; all dry inputs identical | `output/ab_reference_original/AB_COMPARISON_CALIBRATED.json` |
| Source/build inputs | Current source, test and build-script SHA-256 inventory saved | `output/qa/source-inputs-sha256.csv` |
| Packaging | Local ZIP and extracted-file hashes verified by `package_preview.ps1`; exact archive hash stored beside ZIP | `output/qa/package-verification.json`, `Release/*.zip.sha256` |

Final Release VST3 module SHA-256:
`989486BA476BAA77A6644B8507815882139FC535F6E430FF5EFB463806DD365D`.
Final standalone SHA-256:
`853894DABE7376922DBE8D2B1AADA4AE47A7C93562E0487516A89CB55975BBF6`.
Identical native host snapshot SHA-256:
`294672FE2D7D2F32BB4F7B489A7AD231AE28E6FD3B1A9C7ACA418C4C65BBC250`.

In the final six common-setting actual-VST3 comparisons, TB minus UBERLOUD RMS
was -0.338/-0.464 dB (footstep), -0.127/-0.245 dB (voice), and -0.074/-0.145 dB
(pad), for Amount25/50 respectively. All six TB sample peaks were <=0 dBFS.
RMS-matched correlations ranged 0.982446–0.999636. At pad25 the crest factors
still differ by about 2.004 dB, and footstep50's active 20 ms envelope difference
P95 is about 3.168 dB. These remaining differences make an exact-clone claim
inappropriate; numerical agreement is not perceptual approval.

The final short offline stereo benchmark used 48 kHz / 64 frames / 10,000 callbacks
on the current AMD Ryzen 7 260 system: p50 23.3 us, p95 35.1 us, p99 43.9 us,
maximum 231.2 us, against a 1333.333 us block interval. An earlier run reached
7729.1 us with uncontrolled background activity. Both observations are preserved
in `output/qa/performance_history.csv`; the short passing run does not establish
worst-case realtime reliability.

Full measurement artifacts live in the source project, rather than being included
with licensed source audio in the plugin ZIP. `output/AB_UBERLOUD_vs_TB` contains
the separate local audition deliverable. Rebuild with `./build.ps1 -Configuration
Debug` or `Release`; actual-wrapper reproduction is described in
`Tests/Vst3Integration/README.md`.

## 2026-10-15 review and UI v2 build

This build supersedes the binary hashes above. The DSP audio path is unchanged; the
engine gained editor-only metering (K-weighted loudness, per-band lift, gated ΔLU)
that runs only while the editor is showing. Findings of the independent validation are
in `REVIEW_2026-10-15.md`; the UI contract and captures are in `UI_DESIGN.md`.
Pre-review sources and documents are preserved in `_backup/2026-10-15_before_review/`.

| Check | Observed result | Evidence |
|---|---|---|
| Main Release / Debug x64 | PASS; VST3 and Standalone; no compiler warnings | Local MSBuild logs |
| Release Processor / DSP | 100/100 and 54/54 PASS (p50 22 us, p99 40.6 us at 48 kHz / 64 frames) | Test harness output |
| Debug Processor / DSP | 100/100 and 53/53 PASS | Test harness output |
| Actual Release VST3 integration | 85/85 PASS | `Tests/Vst3Integration/outputs/release-wrapper-ui-v2.json` |
| Audio null test against the previous build | 143/143 renders bit-identical (meters on and off, 1003-frame blocks, 3 bands) | `Tests/Validation/nulltest.py` |
| Editor states, Release and Debug | Idle, active, MATCH, bypass, 5.1 rendered without assertions; MATCH residual +0.05 LU on a replayed passage | `output/ui-qa/TB_Loudness_v2_*.png` |
| Release Standalone startup | Running after 4 s; graceful close; exit 0 | `output/ui-qa/TB_Loudness_v2_standalone_live.png` |
| Editor metering cost | +9 % offline processing time while the editor is open | `UI_DESIGN.md` |

UI v2 Release VST3 module SHA-256:
`47F456D5E01444542AA693F5A4D6F904B2FE4417671BC395AD53BF25C124517A`.
UI v2 Release standalone SHA-256:
`6C98C74BFE6C1A8923B6D2D959AE2F779B445F862AF1DDC9D648B4828DBE7CAB`.

`Release/TB_Loudness-0.1.0-Windows-x64-Preview.zip` still contains the previous (v1 UI)
build; `package_preview.ps1` refuses to overwrite it, so a v2 package needs a new
`-PackageName`. The script now takes `TB_Loudness_v2_active.png` as the package `UI.png`.
Human listening, interactive DAW checks and display scaling remain open, as above.

## 2026-10-16 DSP fixes build

Approved fixes for review findings 1–4 (`REVIEW_2026-10-15.md`, section 8). This build
supersedes the UI v2 binary hashes above. Parameters, ranges, state/preset schemas and
factory preset values are unchanged. Pre-change sources, tests and documents are in
`_backup/2026-10-15_before_dsp_fixes/`.

| Change | Observed effect |
|---|---|
| Base-rate peak guard replaced by a 0.5 ms lookahead linked true-peak limiter (12-tap 4x estimate, 10 ms hold, 20 ms release, -0.09 dBTP) | Worst aliasing (-3 dBFS 9.7 kHz, Edge, Clip 100) -21.7 → -84.0 dBc; real-source wet true peak at most +1.88 → -0.05 dBTP up to Clip 50, +2.61 → +0.05 dBTP (4x; +0.14 at 16x) at Clip 100 Edge |
| 1 ms lookahead lift ceiling before the clipper (limits only the added gain) | Onset samples above 0.97 within 10 ms: 258 → 0 at Amount 50; first-ms step gain +8.07 → +5.92 dB |
| First-order ADAA on the sine clipper | Residual Edge/high-Clip aliasing -64 → -84 dBc; -0.1/-0.25/-0.4 dB at 10/16/20 kHz |
| Oversampling latency rounded with two oversampled frames instead of JUCE's Thiran allpass | Lift flat to 20 kHz before ADAA (was -1.43 dB at 20 kHz, Amount 25) |
| Cleanup threshold -84..-36 → -74..-26 dBFS | Cleanup 50 % at Amount 50: -72 dBFS RMS floor lift +22.3 → +6.2 dB |

| Check | Observed result | Evidence |
|---|---|---|
| Main Release / Debug x64 | PASS; VST3 and Standalone; 0 warnings | `output/qa/build_main_*_dspfix.log` |
| Release Processor / DSP | 100/100 and 70/70 PASS (54 previous + 16 wet-path checks) | `output/qa/tests_Release_dspfix.log` |
| Debug Processor / DSP | 100/100 and 69/69 PASS (53 + 16) | `output/qa/tests_Debug_dspfix.log` |
| New checks against the previous engine | 10 of 16 fail (aliasing, true peak, onset, abrupt start, 16/20 kHz, Cleanup); the other 6 guard invariants | `Tests/WetPathTests.h` header |
| Actual Release VST3 integration | 85/85 PASS; 138-sample latency on all six layouts; binary unchanged during the run | `Tests/Vst3Integration/outputs/release-wrapper-dsp-fixes.json` |
| Meters on/off, 1003-frame blocks, 3 bands | 143/143 renders bit-identical (new build against itself) | `Tests/Validation/nulltest.py` |
| Validation reruns and before/after metrics | Static transfer ±0.01 dB; vocals, pad, guitar, bass, full mix, dialogue ±0.03 LU; footstep -1.07 LU and drum loop -0.40 LU at Amount 50 | `Tests/Validation/results/2026-10-16_dsp_fixes/` |
| Editor states, Release and Debug | Idle, active, bypass, MATCH, 5.1 rendered without assertions; MATCH residual 0.003 LU | `output/ui-qa/TB_Loudness_v2_dspfix_*.png` |
| Offline benchmark, 48 kHz / 64 frames | p50 about 29 us versus 23 us for the previous build in the same session (+27 %); p99 34–43 us; deadline 1333 us | Test harness output |
| Loudness-matched A/B audition set (2026-10-17) | 35 previous/fixed pairs on six shared sources; A−B integrated loudness 0.0000 LU; matched files at most -1.00 dBTP; 187 file hashes | `output/AB_dsp_fixes/LISTENING.md`, `metrics.csv`, `EVIDENCE.json` |

DSP-fix Release VST3 module SHA-256:
`E3BF7CA7BBC3388FC0EED0DFC5C286399EF17F0C7D679AA5D98EB60432A5919E`.
DSP-fix Release standalone SHA-256:
`B0F833BCB0A5A55F7490B7F0FCE1F3D7C546EECF03DD488F184C34D42E8B4383`.
Release test harness SHA-256:
`DA394230E6E3FC6F58AC3460C57A7DE77B49FC42B992B786388F699945E91771`.
The idle capture is pixel-identical to `TB_Loudness_v2_idle.png` (`B74BE188…5114`).

Not rerun for this build: standalone startup and packaging. Human listening remains
**NOT RUN**; it now also covers the softer onsets of transient sources, the stronger
Cleanup in factory presets, and brighter top end at low Amount.

## 2026-11-27 band focus and drive mode prototype

Prototype pending listening approval; it supersedes the DSP-fix binaries above. Sources,
tests and documents before it are in `_backup/2026-11-27_before_band_focus/` (with the
previous Release test harness in `bin/`).

| Change | Contract |
|---|---|
| Drive Mode (17th parameter, appended): Clean / Power / Crash, 20 ms crossfade | State schema 2. Schema-1 sessions and presets (16 parameters) open as Power; a schema-1 state naming Drive Mode, or a schema-2 state without it, is rejected unchanged. New instances and Init default to Clean; the other factory presets are Power. |
| Band focus in 2/3-band modes: weight-relative resonant emphasis (FFT-tracked low bell, mid bell, 10 kHz Butterworth shelf) and longer hold/recovery for emphasised bands | No new parameter. Full mode, equal weights and Amount 0 are untouched. |

| Check | Observed result | Evidence |
|---|---|---|
| Main Release / Debug x64 | PASS; VST3 and Standalone; 0 warnings | `output/qa/build_main_*_focus_modes.log` |
| Release Processor / DSP | 103/103 (schema 2 and migration checks) and 77/77 (7 drive/focus checks) PASS | `output/qa/tests_Release_focus_modes.log` |
| Debug Processor / DSP | 103/103 and 76/76 PASS | `output/qa/tests_Debug_focus_modes.log` |
| Power against the previous build | 21/21 offline renders bit-identical (Full, equal-weight 2/3 bands, Amount 0, Clip/Character variants) | `Tests/Validation` session renders |
| Actual Release VST3 integration | 86/86 PASS (17 parameters, one more restore check); 138-sample latency on all six layouts | `Tests/Vst3Integration/outputs/release-wrapper-focus-modes.json` |
| Editor states, Release and Debug | Idle (Clean), active (Footstep Body, Power), bypass, MATCH, 5.1 rendered without assertions; MATCH residual 0.001 LU | `output/ui-qa/TB_Loudness_v3_proto_*.png` |
| Measurements | Clean THD+N -104 to -108 dB; Crash aliasing -71 to -97 dBc on -3 dBFS high sines (above -80 dBc only at Clip 100); all modes -0.12 to +0.08 dBTP; low focus follows a 62 or 110 Hz body (+1.6 / +1.1 dB) | `Tests/Validation/results/2026-11-27_focus_modes/` |
| Audition set | 35 band-focus A/B pairs and 10 drive-mode sequences, matched within 0.0000 LU, at most -1.51 dBTP | `output/AB_band_focus_modes/LISTENING.md` |
| Offline benchmark, 48 kHz / 64 frames, 3 bands | p50 about 35 us (FFT tracker and focus filters run in 2/3-band modes) | Test harness output |

Prototype Release VST3 module SHA-256:
`F16D92F68007D6A81ECCBB4A8F1B02181F5B7A0DB323A40379CF9E7CBE66ADA9`.
Prototype Release standalone SHA-256:
`CC87249C0FA022A05709C7A7EDA9F86E2F3AA5C7FA08D10E8CD6C350E109F802`.

Not rerun: standalone startup, packaging, HostContract snapshots (they record 16 parameters).
Human listening remains **NOT RUN** for the prototype.

## 2026-11-27 UI v3 and state schema 3

Built from the user's eight-point UI brief; it supersedes the prototype binaries above and is
still a prototype pending listening and DAW approval. Sources, tests and documents before it
are in `_backup/2026-11-27_before_ui_v3/` (with the prototype Release test harness in `bin/`).

| Change | Contract |
|---|---|
| Two editor layers in 720 × 434: main (drive strip, FULL one-knob Amount or 2/3-band LOW / MID / HIGH knobs re-laid out per mode, lift glow, LFE SEND slider) and detail (the previous page without COMPARE and the split knobs; LCD widened, 8 s history); DETAIL toggles them | Layer choice lives with the instance only; COMPARE contract kept in `UI_DESIGN.md`; the engine still publishes its measurements |
| Low Split / High Split retired; split fixed at 120 Hz / 2.5 kHz | State schema 3, 15 parameters. The engine keeps a variable split for a later control |
| Low / Mid / High are each band's own amount (0–100 %, default 25 %); Amount drives Full mode only; band focus is relative to the mean band amount | Schema 1/2 states and presets: band = Amount × multiplier / 50, clamped to 100 %; split validated (80–1000 / 1500–10000 Hz) and ignored; schema 1 still opens as Power. A schema-3 state carrying a split, a schema-2 state without one, or schema 4 is rejected unchanged |
| Untracked low focus bell at 0.67 × split (80 Hz) instead of 0.4 × split | Keeps the bell inside the 120 Hz low band |

| Check | Observed result | Evidence |
|---|---|---|
| Main Release / Debug x64 | PASS; VST3 and Standalone; 0 warnings | `output/qa/build_main_*_ui_v3.log` |
| Release Processor / DSP | 111/111 (schema 3, migration, clamping, retired-split rejection) and 77/77 PASS; p50 35.5 us at 48 kHz / 64 frames | `output/qa/tests_Release_ui_v3.log` |
| Debug Processor / DSP | 111/111 and 76/76 PASS | `output/qa/tests_Debug_ui_v3.log` |
| Actual Release VST3 integration | 84/84 PASS (15 parameters); 138-sample latency on all six layouts; binary unchanged during the run | `Tests/Vst3Integration/outputs/release-wrapper-ui-v3.json` |
| Null test against the prototype | Full mode 60/60 and equal-amount 2/3-band 10/10 bit-identical; unequal 2/3-band amounts differ only through the low focus bell (with the prototype's bell rule: 10/10 bit-identical) | `Tests/Validation/results/2026-11-27_schema3_null/` |
| Editor captures, main and detail | 10 states rendered without assertions | `output/ui-qa/TB_Loudness_ui3_*.png`, hashes in `UI_DESIGN.md` |

UI v3 Release VST3 module SHA-256:
`EDE2C92E64A3F8F0FF9448FD8433033B126F8F9D29A1695C2C4E018A9549F9BE`.
UI v3 Release standalone SHA-256:
`DBD1F1744784A0AB08F500E552B6F7469F55781C34F880DA6F2940DF8AFF6B8E`.

Not rerun: standalone startup, packaging, HostContract snapshots (they record 16 parameters).
Human listening remains **NOT RUN**; for this build it also covers 2/3-band sessions saved
before schema 3, whose band edges move from 250 Hz / 4 kHz to 120 Hz / 2.5 kHz.

### Bypass button and band colours (2026-11-27, editor only)

BYPASS returned as a header toggle on both pages (the Bypass parameter, shared with the host).
LOW / MID / HIGH knobs, their glows and the detail LIFT bars use dark, lightly saturated blue
`#4A78A6`, green `#4E8F6C` and red `#A9503F`; the glow is fainter and softer (peak alpha 0.40,
Gaussian-like falloff). Audio, parameters and state are unchanged. Editor sources and documents
before this step are in `_backup/2026-11-27_before_band_colours/`.

| Check | Observed result | Evidence |
|---|---|---|
| Main Release / Debug, test harness Release / Debug | PASS; 0 warnings | `output/qa/build_*_band_colours.log` |
| Release Processor / DSP | 111/111 and 77/77 PASS | `output/qa/tests_Release_band_colours.log` |
| Debug editor | Active 3-band capture rendered without assertions | `output/qa/debug_editor_band_colours.png` |
| Actual Release VST3 integration | 84/84 PASS; binary unchanged during the run | `Tests/Vst3Integration/outputs/release-wrapper-band-colours.json` |
| Editor captures | 10 states re-rendered; hashes in `UI_DESIGN.md` | `output/ui-qa/TB_Loudness_ui3_*.png` |

Release VST3 module SHA-256 (supersedes the UI v3 hash above):
`BD97EF70B3F972DD62FAFD0ECBAD6AB28A9A0FFCBC4E895A1DC395C20F0AA702`.
Release standalone SHA-256:
`65718FA97BDD0011B2166DADE3164B9FF0AB3A2D9E74D4464DE26BDFB8BFC8FC`.

### House style (2026-11-28, editor only)

`PluginEditor.cpp` redrawn in the TB house style (see `UI_DESIGN.md`, House style). Layout,
parameters, state and DSP sources are untouched. Shared `TBParts.h`, `TBFonts.h`,
`Source/Assets/Parts` and `Source/Assets/Fonts` added to the plug-in and test projects.

| Check | Observed result | Evidence |
|---|---|---|
| Release Processor / DSP harness | 111/111 and 77/77 PASS | `output/qa/tests_Release_house.log` |
| Actual Release VST3 integration | 84/84 PASS | `Tests/Vst3Integration/outputs/release-wrapper-house.json` |
| Host contract probe with `--ui` | All checks PASS, 15 parameters, native UI attach / paint / remove PASS | `output/qa/host-contract-house.json` |
| Latency and bypass return (TimelineProbe on the Release VST3) | Impulse first and peak at sample 138 (unchanged); nothing left over after bypass return (-200 dBFS) | session log |
| Editor captures | 10 states; hashes in `UI_DESIGN.md` | `output/ui-qa/house/` |

Release VST3 module SHA-256 (supersedes the band-colour hash above):
`A241853150339E7E9A177578BD2DEC9D1B7F21F68188301F1382297430E30DC8`.
Release standalone SHA-256:
`99E43CBCA0841DECCAA507D7B2360158D043AE0433A5585DD5CF8384016EF734`.

Not run for this step: Debug builds, standalone startup, audio null test against the previous
build (no DSP source changed), display scaling in a real DAW, human listening.
